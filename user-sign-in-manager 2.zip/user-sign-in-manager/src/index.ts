import { Hono } from 'hono';
import { cors } from 'hono/cors';

interface UserData {
  firstName: string;
  lastName: string;
  email: string;
  status: 'Active' | 'Inactive';
  lastSignIn: string;
  emailUsage: string;
}

interface Env {
  USER_DATA: KVNamespace;
}

const app = new Hono<{ Bindings: Env }>();

app.use('*', cors());

// Helper to parse the raw CSV format
const parseRawLine = (line: string): UserData | null => {
  const parts = line.split(',').map(p => p.trim());
  if (parts.length < 6) return null;

  return {
    firstName: parts[0],
    lastName: parts[1],
    email: parts[2],
    status: parts[3] as 'Active' | 'Inactive',
    lastSignIn: parts[4],
    emailUsage: parts[5],
  };
};

// GET /user/:email - Retrieve user by email
app.get('/user/:email', async (c) => {
  const email = c.req.param('email');
  const data = await c.env.USER_DATA.get(email);

  if (!data) {
    return c.json({ error: 'User not found' }, 404);
  }

  return c.json(JSON.parse(data));
});

// POST /user/import - Import a single CSV line
app.post('/user/import', async (c) => {
  const rawText = await c.req.text();
  const userData = parseRawLine(rawText);

  if (!userData) {
    return c.json({ error: 'Invalid data format. Expected: FirstName,LastName,Email,Status,LastSignIn,EmailUsage' }, 400);
  }

  await c.env.USER_DATA.put(userData.email, JSON.stringify(userData));

  return c.json({ message: 'User imported successfully', user: userData });
});

// POST /user/import-csv - Import full CSV including header row
app.post('/user/import-csv', async (c) => {
  const rawText = await c.req.text();
  const lines = rawText.trim().split('\n');
  const imported: UserData[] = [];
  const errors: string[] = [];

  // Skip header row if present
  const dataLines = lines[0].toLowerCase().includes('first name') ? lines.slice(1) : lines;

  for (const line of dataLines) {
    if (!line.trim()) continue;
    const userData = parseRawLine(line);
    if (!userData) {
      errors.push(`Could not parse: ${line}`);
      continue;
    }
    await c.env.USER_DATA.put(userData.email, JSON.stringify(userData));
    imported.push(userData);
  }

  return c.json({ message: `Imported ${imported.length} user(s)`, imported, errors });
});

// GET /users - List all users
app.get('/users', async (c) => {
  const list = await c.env.USER_DATA.list();
  const users: UserData[] = [];

  for (const key of list.keys) {
    const data = await c.env.USER_DATA.get(key.name);
    if (data) users.push(JSON.parse(data));
  }

  return c.json({ count: users.length, users });
});

// DELETE /user/:email - Remove a user
app.delete('/user/:email', async (c) => {
  const email = c.req.param('email');
  await c.env.USER_DATA.delete(email);
  return c.json({ message: `User ${email} deleted` });
});

export default app;
