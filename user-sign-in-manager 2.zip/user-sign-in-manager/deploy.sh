#!/bin/bash
# deploy.sh - Run this from the project folder after adding your API token

# 1. Install dependencies
npm install

# 2. Deploy the worker
npx wrangler deploy

# 3. Seed Tim Henderson's data into KV
echo "Seeding Tim Henderson's data..."
npx wrangler kv key put \
  --binding=USER_DATA \
  --namespace-id=cb3ac91a6d404f29ba30ba8e8f52d82a \
  "tim.henderson@bluelighttechcompany.com" \
  '{"firstName":"Tim","lastName":"Henderson","email":"tim.henderson@bluelighttechcompany.com","status":"Active","lastSignIn":"2022/03/27 21:32:06","emailUsage":"0.0GB"}'

echo ""
echo "✅ Done! Your worker is live."
echo ""
echo "Test it:"
echo "  curl https://user-sign-in-manager.<your-subdomain>.workers.dev/user/tim.henderson@bluelighttechcompany.com"
